import 'package:car/consts/icons.dart';
import 'package:flutter/material.dart';

Widget icone({Widget? child}) {
  return Image.asset(dashicon,
      width: double.infinity, fit: BoxFit.cover, height: 120);
}
