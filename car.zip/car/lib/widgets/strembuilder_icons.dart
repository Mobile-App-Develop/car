// import '../consts/const.dart';
//
// Widget iconbottom() {
//   return GridView.builder(
//       physics: NeverScrollableScrollPhysics(),
//       shrinkWrap: true,
//       itemCount: 4,
//       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//           childAspectRatio: 1,
//           crossAxisCount: 4,
//           mainAxisSpacing: 0,
//           crossAxisSpacing: 0,
//           mainAxisExtent: 50),
//       itemBuilder: (context, index) {
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               loginBottomBarIcons[index], size: 30,
//               color: Colors.black87,
// // fit: BoxFit.cover,
//             ),
// // 10.heightBox,
//             "${loginBottomBarString[index]}"
//                 .text
//                 .size(5)
//                 .bold
//                 .color(Colors.black54)
//                 .align(TextAlign.center)
//                 .make()
//           ],
//         )
//             .box
//             .color(Colors.white)
//             .roundedSM
//             .outerShadow
//             .width(context.screenWidth)
//             .make()
//             .onTap(() {
//           Get.to(() => homeScreenNewscreen[index]);
//         });
//       });
// }
