const bold = "assets/fonts/sans_bold.ttf";
const regular = "assets/fonts/MaterialIcons-Regular.otf";
const semibold = "assets/fonts/sans_semibold.ttf";
