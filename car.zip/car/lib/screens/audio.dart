import 'package:car/consts/const.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../consts/icons.dart';

class audio extends StatefulWidget {
  const audio({super.key});

  @override
  State<audio> createState() => _audioState();
}

class _audioState extends State<audio> {
  RangeValues values = RangeValues(0.00, 2.00);

  @override
  Widget build(BuildContext context) {
    RangeLabels labels =
        RangeLabels(values.start.toString(), values.end.toString());
    return SliderTheme(
        data: SliderThemeData(
            overlayShape: SliderComponentShape.noOverlay,
            trackHeight: 1,
            trackShape: RectangularSliderTrackShape()),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              Image.asset(
                girl2,
                width: 60.w,
                height: 60.h,
                fit: BoxFit.fill,
              ),
              5.widthBox,
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  4.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      "Love me like you do".text.size(1).color(white).make(),
                      13.widthBox,
                      Icon(
                        Icons.share,
                        color: white,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      "Ellie Goulding".text.size(2).white.make(),
                      10.widthBox,
                      Icon(
                        Icons.fast_rewind,
                        color: white,
                      ),
                      Icon(
                        Icons.skip_previous_rounded,
                        color: white,
                      ),
                      Icon(
                        Icons.pause,
                        color: white,
                      ),
                      Icon(
                        Icons.skip_next,
                        color: white,
                      ),
                      Icon(
                        Icons.fast_forward,
                        color: white,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      RangeSlider(
                          values: values,
                          labels: labels,
                          min: 0.00,
                          max: 2.00,
                          activeColor: yellow,
                          inactiveColor: white,
                          divisions: 40,
                          onChanged: (newValue) {
                            values = newValue;
                            setState(() {});
                          }),
                    ],
                  ),
                ],
              ),
            ],
          ).box.color(gray).roundedSM.make(),
        ));
  }
}
