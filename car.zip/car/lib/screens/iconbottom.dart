import 'package:car/consts/const.dart';
import 'package:car/consts/icons.dart';

class iconbottom extends StatelessWidget {
  const iconbottom({super.key});

  @override
  Widget build(BuildContext context) {
    return Wrap(children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          InkWell(
            splashColor: Colors.green, // splash color
            onTap: () {}, // button pressed
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  humidty,
                  color: white,
                  width: 20,
                  height: 20,
                ), // icon
                "Humidity".text.color(white).size(1).make() // text
              ],
            ),
          ).box.roundedSM.color(gray).width(60).height(50).make(),
          2.widthBox,
          InkWell(
            splashColor: Colors.green, // splash color
            onTap: () {}, // button pressed
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  wind,
                  width: 20,
                  height: 20,
                  color: white,
                ), // icon
                "Wind".text.color(white).size(1).make() // text
              ],
            ),
          ).box.roundedSM.color(gray).width(60).height(50).make(),
          2.widthBox,
          InkWell(
            splashColor: Colors.green, // splash color
            onTap: () {}, // button pressed
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  bluethoth,
                  width: 20,
                  height: 20,
                  color: white,
                ), // icon
                "Bluetooth".text.color(white).size(1).make() // text
              ],
            ),
          ).box.roundedSM.color(gray).width(60).height(50).make(),
          2.widthBox,
          InkWell(
            splashColor: Colors.green, // splash color
            onTap: () {}, // button pressed
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  messaage,
                  width: 20,
                  height: 20,
                  color: white,
                ), // icon
                "Message".text.color(white).size(1).make() // text
              ],
            ),
          ).box.roundedSM.color(gray).width(60).height(50).make(),
          2.widthBox,
          InkWell(
            splashColor: Colors.green, // splash color
            onTap: () {}, // button pressed
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  arm,
                  width: 20,
                  height: 20,
                  color: white,
                ), // icon
                "20".text.color(white).bold.size(1).make() // text
              ],
            ),
          ).box.roundedSM.color(gray).width(60).height(50).makeCentered(),
        ],
      ).box.height(100).makeCentered(),
    ]);
  }
}
