import 'package:car/consts/const.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Widget icons() {
  return Container(
    width: 2.w,
    height: 100.h,
    color: white,
  );
}
