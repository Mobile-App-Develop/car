//icon string
import 'package:car/consts/const.dart';
import 'package:car/consts/icons.dart';

const homeBottomBarString = [
  humidty,
  winds,
  bluetooth,
  message,
];
//icons
const homeBottomBarIcons = [];
