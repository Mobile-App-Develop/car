import 'dart:ui';

import 'package:flutter/material.dart';

const Color white = Color(0xffFFFFFF);
const Color yellow = Color(0xffCFF80B);
const Color pink = Color(0xffFF2257);
const Color black = Color(0xff111111);
const Color green = Color(0xff00FFA4);
const Color gray = Color(0xff1E1E1E);
const Color gro = Color(0xff87888C);
