import 'package:car/consts/const.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../consts/icons.dart';

Widget searchBar() {
  return Flexible(
    fit: FlexFit.tight,
    child: Row(children: [
      Image.asset(
        dashicon,
        width: 30,
        height: 30,
        color: white,
      ),
      10.widthBox,
      dashboards.text.color(white).size(18).bold.make(),
      10.widthBox,
      Row(
        children: [
          5.widthBox,
          TextField(
            // cursorHeight: 1,
            decoration: InputDecoration(
                alignLabelWithHint: true,
                filled: true,
                fillColor: white,
                prefixIcon: Image.asset(
                  searches,
                  width: 10,
                  height: 10,
                ),
                hintText: search,
                hintStyle: TextStyle(
                  height: 1,
                  fontSize: 2,
                  fontFamily: regular,
                  color: white,
                ),
                focusColor: Colors.blue,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                )),
          ).box.width(180.w).height(39.h).make(),
        ],
      ),
      10.widthBox,
      Row(
        children: [
          Image.asset(
            ellipse,
            width: 30,
            height: 30,
            // color: white,
          ),
          5.widthBox,
          "25 C".text.color(white).make(),
        ],
      ),
      10.widthBox,
      Row(
        children: [
          Image.asset(
            notification,
            width: 15,
            height: 15,
            // color: white,
          ),
        ],
      ),
      5.widthBox,
      Row(
        children: [
          Image.asset(
            girl,
            width: 30,
            height: 30,
            // color: white,
          ),
        ],
      ),
    ]),
  );
}
