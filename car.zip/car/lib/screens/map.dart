import 'package:car/consts/const.dart';
import 'package:car/consts/icons.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class map extends StatelessWidget {
  const map({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Column(
        children: [
          Container(
              child: Row(
            children: [
              Image.asset(
                arrow,
                width: 28,
                height: 28,
                color: Colors.yellow,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  "600m".text.size(18).color(white).bold.make(),
                  "In 500m take tuning"
                      .text
                      .size(Vx.dp0)
                      .color(Vx.gray100)
                      .overflow(TextOverflow.ellipsis)
                      .maxLines(2)
                      .softWrap(false)
                      .make(),
                ],
              )
            ],
          ).box.color(gray).roundedSM.make()),
          Image.asset(
            mapps,
            fit: BoxFit.fill,
          ).box.height(252.h).width(140.w).make(),
          Row(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  "Club town garden".text.size(4).white.make(),
                  "MM Feeder Road Kalkata".text.size(2).gray100.make(),
                  "2 Km ------------- 3 min".text.size(4).gray100.make()
                ],
              ),
              10.widthBox,
              IconButton(
                // alignment: Alignment.center,
                onPressed: () {},
                icon: Icon(
                  Icons.search,
                  color: Colors.white,
                  size: 20,
                ),

                // IconButton((){},
                //
              )
                  .box
                  .color(gray)
                  .alignment(Alignment.topRight)
                  .width(10.w)
                  .height(20.h)
                  .roundedFull
                  .make()
            ],
          ).box.color(gray).width(100.w).make(),
        ],
      ),
    );
  }
}
