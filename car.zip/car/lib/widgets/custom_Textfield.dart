import '../consts/const.dart';

Widget customTextField({
  String? hint,
  icon,
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // title!.text.bold.make(),
      5.heightBox,
      TextFormField(
        // obscureText: isPass,
        // controller: controller,
        decoration: InputDecoration(
          icon: icon,
          hintText: hint,
          isDense: true,
          fillColor: white,
          filled: true,
          border: InputBorder.none,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
                // color: redColor,
                ),
          ),
        ),
      ),
      20.heightBox,
    ],
  );
}
