import 'package:car/consts/const.dart';
import 'package:car/screens/audio.dart';
import 'package:car/screens/calander.dart';
import 'package:car/screens/car.dart';
import 'package:car/screens/climate.dart';
import 'package:car/screens/iconbottom.dart';
import 'package:car/screens/icons.dart';
import 'package:car/screens/map.dart';
import 'package:car/widgets/search%20bar.dart';

class dashboard extends StatelessWidget {
  const dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          backgroundColor: black,
          body: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  //SEARCH BAR
                  Expanded(
                    flex: 1,
                    child: Container(
                      // color: Colors.blue,
                      child: searchBar(),
                    ),
                  ),
                  5.heightBox,
                  Expanded(
                    flex: 9,
                    child: Row(
                      children: [
                        //1st part 1%
                        //icons
                        Expanded(
                          flex: 1,
                          child: Container(
                            // color: Colors.blue,
                            child: icon(),
                          ),
                        ),
                        2.widthBox,
                        //2nd part 5%
                        Expanded(
                          flex: 6,
                          child: Row(
                            children: [
                              //66m
                              Expanded(
                                flex: 6,
                                child: Column(
                                  children: [
                                    //6m screen
                                    Expanded(
                                      flex: 7,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 6,
                                            child: Container(
                                              // color: Colors.blue,
                                              child: map(),
                                            ),
                                          ),
                                          2.widthBox,
                                          //climate screen
                                          Expanded(
                                            flex: 4,
                                            child: Column(
                                              children: [
                                                Expanded(
                                                  flex: 6,
                                                  child: Container(
                                                    // color: Colors.blue,
                                                    child: climate(),
                                                  ),
                                                ),
                                                2.heightBox,
                                                Expanded(
                                                  flex: 6,
                                                  child: Container(
                                                    // color: Colors.blue,
                                                    child: clander(),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    2.heightBox,
                                    //love song

                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        // color: Colors.blue,
                                        child: audio(),
                                      ),
                                    ),
                                    2.heightBox,
                                    //huily icons
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        // color: Colors.blue,
                                        child: iconbottom(),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        2.widthBox,
                        //3rd part 4%
                        Expanded(
                          flex: 3,
                          child: Container(
                            // color: Colors.blue,
                            child: cars(),
                          ),
                        ),
                        2.widthBox,
                      ],
                    ),
                  )
                ],
              ).box.rounded.make())),
    );
  }
}
