import 'package:car/consts/const.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class icon extends StatelessWidget {
  const icon({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        //home
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.home,
              color: Colors.white,
              size: 20,
            ).box.roundedFull.color(gray).width(40.w).height(40.h).make()),
        2.heightBox,
        //camera
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.camera_alt_outlined,
              color: Colors.white,
              size: 20,
            ).box.roundedFull.color(gray).width(40.w).height(40.h).make()),
        2.heightBox,
        //phone
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.phone,
              color: Colors.white,
              size: 20,
            ).box.roundedFull.color(gray).width(40.w).height(40.h).make()),
        2.heightBox,
        //player
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.play_circle_fill,
              color: Colors.white,
              size: 20,
            ).box.roundedFull.color(gray).width(40.w).height(40.h).make()),
        2.heightBox,
        //seeting
        IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.settings,
              color: Colors.white,
              size: 20,
            ).box.roundedFull.color(gray).width(40.w).height(40.h).make()),
        2.heightBox,
      ],
    );
  }
}
