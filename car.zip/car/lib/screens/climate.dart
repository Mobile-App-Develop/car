import 'package:car/consts/const.dart';
import 'package:car/consts/icons.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class climate extends StatelessWidget {
  const climate({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        "Climate".text.size(12).bold.white.make(),
        5.heightBox,
        "INTERIOR 24 C".text.size(12).gray700.make(),
        Row(
          children: [
            "23o C".text.size(22).white.make(),
            5.widthBox,
            Image.asset(
              cli,
              width: 30,
              height: 50,
            )
          ],
        ),
        5.heightBox,
        "WINDOW CLOSED".text.size(12).white.make(),
      ],
    ).box.width(80.w).height(200.h).color(gray).roundedSM.make();
  }
}
