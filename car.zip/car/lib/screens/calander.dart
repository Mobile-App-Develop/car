import 'package:car/consts/const.dart';

class clander extends StatefulWidget {
  const clander({super.key});

  @override
  State<clander> createState() => _clanderState();
}

class _clanderState extends State<clander> {
  // RangeValues values = RangeValues(0.00, 2.00);

  double value = 5;

  @override
  Widget build(BuildContext context) {
    // RangeLabels labels =
    //     RangeLabels(values.start.toString(), values.end.toString());
    final double min = 0;
    final double max = 10;

    return SliderTheme(
        data: SliderThemeData(
            overlayShape: SliderComponentShape.noOverlay,
            trackHeight: 50,
            trackShape: RectangularSliderTrackShape()),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              children: [
                "My Calender".text.white.size(12).bold.make(),
                7.widthBox,
                "...".text.white.size(12).bold.make(),
              ],
            ),
            "5 Aug - 2022".text.size(9).color(gro).make(),
            1.heightBox,
            "----------------------".text.size(9).color(yellow).make(),
            Row(
              children: [
                "5:00".text.size(9).bold.color(gro).makeCentered(),
                Stack(children: [
                  RotatedBox(
                    quarterTurns: 4,
                    child: Slider(
                        value: value,
                        label: value.round().toString(),
                        min: min,
                        max: max,
                        activeColor: yellow,
                        inactiveColor: gro,
                        divisions: 10,
                        onChanged: (value) =>
                            // value = value;
                            setState(() => this.value = value)),
                  ),
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        2.heightBox,
                        "       Meeting with Clients"
                            .text
                            .size(3)
                            .bold
                            .color(white)
                            .makeCentered(),
                      ],
                    ),
                  ),
                  2.heightBox,
                  // "5:00 - 6:20 with Clients"
                  //     .text
                  //     .size(11)
                  //     .bold
                  //     .color(gro)
                  //     .makeCentered(),
                ]),
              ],
            ),
            Row(
              children: [
                "6:00".text.size(9).bold.color(gro).makeCentered(),
              ],
            ),
            Row(
              children: [
                "------------------------------------------------"
                    .text
                    .size(9)
                    .bold
                    .color(gro)
                    .makeCentered(),
              ],
            ),
          ],
        ).box.color(gray).make());
  }
}
