import 'package:car/consts/const.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class cars extends StatefulWidget {
  const cars({super.key});

  @override
  State<cars> createState() => _carsState();
}

class _carsState extends State<cars> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              "assets/icons/emr.png",
              width: 28,
              height: 28,
            ).box.color(gray).make(),
            2.widthBox,
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                "Emergency".text.size(5).bold.color(white).make(),
                "Swithch On Only in emergency case"
                    .text
                    .size(1)
                    .bold
                    .color(gro)
                    .make(),
              ],
            ),
            2.widthBox,
            Image.asset(
              "assets/icons/button.png",
              width: 38,
              height: 28,
            ),
          ],
        ).box.color(gray).make(),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              car,
              width: 250.w,
              height: 150.h,
              fit: BoxFit.fill,
            )
          ],
        ),
        6.heightBox,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            InkWell(
              onTap: () {},
              child: Column(
                children: [
                  Image.asset(
                    brithnessIcon,
                    width: 30,
                    height: 30,
                  ),
                  "Brithness".text.white.size(5).make()
                ],
              ),
            ),
            8.widthBox,
            InkWell(
              onTap: () {},
              child: Column(
                children: [
                  Image.asset(
                    fingureicon,
                    width: 30,
                    height: 30,
                  ),
                  "Fingerprint".text.white.size(5).make()
                ],
              ),
            ),
            8.widthBox,
            InkWell(
              onTap: () {},
              child: Column(
                children: [
                  Image.asset(
                    status,
                    width: 30,
                    height: 30,
                  ),
                  "Statisitcs".text.white.size(5).make()
                ],
              ),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {},
              child: Image.asset(
                sixtyFive,
                scale: 2,
              ),
            ),
            12.widthBox,
            InkWell(
              onTap: () {},
              child: Image.asset(
                sixty,
                scale: 2,
              ),
            ),
          ],
        ),
        InkWell(
          onTap: () {},
          child: Image.asset(
            garicon,
            scale: 2,
          ),
        ),
      ],
    );
  }
}
